// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP102/112 assignment.
// You may not distribute it in any other way without permission.

/* Code for COMP-102-112 - 2022T1, Assignment 7
 * Name:
 * Username:
 * ID:
 */

import ecs100.*;
import java.awt.Color;

/** The robot is a circular vacuum cleaner than runs around
 * a floor, erasing any "dirt".
 * The parameters of the constructor should include the initial position,
 * and possibly its size and color.
 * It has methods to make it step and change direction:
 *  step() makes it go forward one step in its current direction.
 *  changeDirection() makes it go backward one step, and then turn to a new
 *     (random) direction.
 * It has methods to report its current position (x and y) with the
 *     getX() and getY() methods.
 * It has methods to erase and draw itself
 *  draw() will make it draw itself,
 *  erase() will make it erase itself (cleaning the floor under it also!)
 *
 * Hint: if the current direction of the robot is d (expressed in
 *  degrees clockwise from East), then it should step
 *     cos(d * pi/180) in the horizontal direction, and
 *     sin(d * pi/180) in the vertical direction.
 * Hint: see the Math class documentation!
 */

public class Robot{

    // Fields to store the state of the robot.
    /*# YOUR CODE HERE */

    /** Construct a new Robot object.
     *  set its direction to a random direction, 0..360
     */
    public Robot(double diam, double xpos, double ypos, Color color){
        /*# YOUR CODE HERE */

    }

    // Methods to return the x and y coordinates of the current position 
    /*# YOUR CODE HERE */

    /** Step one unit in the current direction (but don't redraw) */
    public void step(){
        /*# YOUR CODE HERE */

    }

    /** changeDirection: move backwards one unit and change direction randomly */
    public void changeDirection(){
        /*# YOUR CODE HERE */

    }

    /** Erase the robot */
    public void erase(){
        /*# YOUR CODE HERE */

    }

    /** Draw the robot */
    public void draw(){
        /*# YOUR CODE HERE */

    }
}
